#!/usr/bin/env bash

# Java 8
apt-get -y install openjdk-8-jdk
