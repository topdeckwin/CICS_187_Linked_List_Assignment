Here you would include all jars that the execution depends on. For this example:

- checkstyle-8.12-all.jar
- jgrade-1.1-all.jar
